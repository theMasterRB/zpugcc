Add a self-contained Tier 0 ZPU regression suite so contributors can run the
required-instruction tests before the C++ simulator and RTL are ready. The package
contains 19 assembly programs, 500 external result checks, prebuilt ZPU images,
a Java 8-compatible adapter, and the pinned original Zylin simulator with its
source and upstream license notice.

Run `./run_tests.sh` from the package directory with Python 3.7+ and Java 8+.
No separate simulator clone, ZPU toolchain, Java compiler or UART is needed for
the included images. The checker rejects incomplete execution and incorrect
results and preserves per-run traces, memory dumps and provenance.

Validation: all 19 programs / 500 result checks pass on the bundled reference
under Java 8; host safeguards pass; wrong arithmetic, an early breakpoint and
instruction-budget exhaustion are rejected. The proposed standalone platform is
32 KiB big-endian RAM with PC=0 and SP=0x7ff8. C++/RTL integration and Tier 1
emulation-dispatch testing remain separate work.
