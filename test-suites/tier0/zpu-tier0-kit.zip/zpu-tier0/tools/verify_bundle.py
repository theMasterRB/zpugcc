#!/usr/bin/env python3
"""Verify the packaged program images, adapter, and unchanged upstream files."""
import hashlib
import json

from run import ROOT, binary_to_hex, check_opcodes, read_manifest, source_hashes


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    manifest = read_manifest()
    reference = json.loads((ROOT / "reference.json").read_text())
    jar = ROOT / reference["bundled_jar_path"]
    require(sha(jar) == reference["jar_sha256"], "Simulator JAR checksum mismatch")
    bytecode = reference["adapter_bytecode"]
    require(sha(ROOT / reference["adapter"]) == bytecode["source_sha256"],
            "Adapter source changed without recompilation")
    for name, expected in bytecode["classes"].items():
        path = ROOT / bytecode["directory"] / name
        require(sha(path) == expected, f"Adapter class checksum mismatch: {name}")
        raw = path.read_bytes()
        require(raw[:4] == bytes.fromhex("cafebabe") and int.from_bytes(raw[6:8], "big") == 52,
                f"Adapter class is not Java 8 format: {name}")
    vendor = ROOT / "reference/zylin"
    upstream = json.loads((vendor / "UPSTREAM.json").read_text())
    for name, expected in upstream["files_sha256"].items():
        require(sha(vendor / name) == expected, f"Upstream file changed: {name}")
    require((vendor / "COPYING").is_file() and (vendor / "GPL-2.txt").is_file(),
            "Upstream license notice/text missing")
    for name in manifest["tests"]:
        image = ROOT / "build" / f"{name}.bin"
        raw = image.read_bytes()
        check_opcodes(raw)
        record = json.loads(image.with_suffix(".build.json").read_text())
        require(record["sources"] == source_hashes(name), f"Stale source record: {name}")
        require(record["image_sha256"] == sha(image), f"Image checksum mismatch: {name}")
        require(image.with_suffix(".hex").read_text() == binary_to_hex(raw),
                f"Hex packing mismatch: {name}")
        require(image.with_suffix(".elf").is_file(), f"ELF missing: {name}")
    checks = sum(len(cases) for cases in manifest["tests"].values())
    print(f"VERIFIED: {len(manifest['tests'])} programs / {checks} checks; "
          f"adapter and {len(upstream['files_sha256'])} unchanged upstream files.")


if __name__ == "__main__":
    main()
