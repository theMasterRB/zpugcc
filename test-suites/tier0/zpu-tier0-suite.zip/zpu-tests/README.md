# ZPU Tier 0 suite

**19 assembly programs; 500 externally checked result words.** Tests use only
required hardware instructions. No C library, UART, comparison opcode, software
opcode handler, interrupt handler or bootloader is involved.

Start with `tier0/immediates.S`, then `addition.S`, `memory.S`, and `bitwise.S`.
`COVERAGE.md` explains every program and the remaining limitations. Every result
slot and expected value is described in `manifest.json`.

## Build

Requires Python 3.7+ and the ZPU GNU assembler, linker, objcopy and objdump. With
your toolchain on PATH:

```sh
python3 tools/run.py build
```

Or specify its actual prefix, including the final dash:

```sh
python3 tools/run.py build --tool-prefix /path/to/bin/zpu-elf-
```

In this cloud workspace the tested prefix is:

```sh
python3 tools/run.py build --tool-prefix /workspace/zpu-dev/source-install/bin/zpu-elf-
```

Add a test name after `build` to build only that test. Per-test outputs are `.o`,
`.elf`, `.bin`, `.hex`, `.map`, `.dis`, and `.build.json`. Hex images contain one
big-endian 32-bit word per line, with trailing zero padding as needed.

The builder rejects undefined/emulated opcode bytes, images overlapping the
result area, and extra/missing breakpoints. Build records bind images to their
source, common files and manifest; the Java runner rejects stale/modified images.
An old source-built linker fails on script ASSERT, so Python checks code size.

`PUSH32` emits NOP and five explicit IM bytes. This avoids the assembler's
optimization of some constants to IM plus FLIP. The basic IM tests use explicit
one-, two- and three-byte encodings as well. Zero-valued data is not BREAKPOINT:
IM zero is opcode byte 0x80; only fetching instruction byte 0x00 breaks.

## Run on Zylin's original Java simulator

An optional adapter executes the actual upstream Java simulator, not a Python CPU
model. It uses the pinned JAR identified by `reference.json`. The JAR itself is
not bundled. Obtain it from the recorded upstream commit if you do not have it:

```sh
git clone https://github.com/zylin/zpu.git /path/to/zylin-zpu
git -C /path/to/zylin-zpu checkout e29aef5f7aa741557d0eb16ecf13e974d55789ff
python3 tools/run.py reference --jar /path/to/zylin-zpu/zpu/sw/simulator/zpusim.jar
```

Use a new directory for that clone; do not reset an existing checkout containing
someone's work. **Java 8 or newer is sufficient. A JRE is enough; no Java compiler
or newer Java module is needed to run the tests.** The package includes the
adapter's Java 8 class files in `tools/java8/`. The command verifies their format,
checksums and source hash, as well as the upstream JAR checksum. To run one test:

```sh
python3 tools/run.py reference immediates --jar /path/to/zpusim.jar
```

Use `java -version` with ONE dash to check Java 8. If several Java installations
exist, `--java /path/to/bin/java` selects one without changing the server default.
The prebuilt ZPU images are included, so initial execution does not need the ZPU
compiler. Rebuild only after changing assembly/common/manifest files.

Every invocation gets a new `runs/java-ref-*/` directory. Each test produces:

* `status.txt`: HALT, TIMEOUT, IO_ACCESS or another fault, plus execution details.
* `dump.hex`: the complete 32 KiB RAM contents, eight hex digits per word.
* `trace.txt`: PRE-execution PC, opcode, SP, TOS, NOS; one row per fetched byte.
* `provenance.json`: image, manifest and adapter hashes, command and budget.
* `backend.stdout` and `backend.stderr`: adapter output.

A top-level `summary.json` reports all outcomes. The default instruction budget
is 20,000 per program, independent of the 30-second host timeout per invocation.
`--max-instructions N` changes the architectural budget. HALT alone is not PASS:
the completion marker and all expected words must match.

The adapter changes platform configuration (RAM size, initial SP, memory bounds,
disabled devices), but does not reimplement any opcode. It invokes a private loop
in the pinned upstream simulator to distinguish breakpoint from other exceptions.
That is why its version is pinned. This backend is distinct from the team's
Questa reference, C++ simulator, and RTL; those need their own execution results.

## Run on the team's Questa backend

The team's backend is not included. Their uploaded documentation describes:

```sh
module load siemens/questa/2023.4
ZPU=~/zpu backends/zylin-ref/tools/compile_questa.sh
backends/zylin-ref/tools/run_one.sh build/immediates.bin
python3 tools/run.py check immediates run/immediates
```

Confirm the actual run directory and memory contract first. The checker expects
`status.txt` beginning with HALT and a full `dump.hex` of exactly 8192 known words,
starting at address zero (line 1 = address 0, line 2 = address 4). It rejects X/Z,
missing/truncated/malformed files and abnormal termination. Initialize unused RAM
or deliberately adapt the dump contract if your backend leaves it unknown.

`check` reads supplied files; it cannot prove manually selected files are fresh
or from the right program. Execute into a fresh directory for each test. The Java
runner handles that automatically. No UART device is needed.

## Standalone memory contract

These are test settings, not a confirmed project/SoC memory map:

| Region | Byte addresses |
| --- | --- |
| Writable RAM | 0x0000..0x7fff (32 KiB) |
| Entry PC | 0x0000 |
| Code | Below 0x1000 |
| Completion word | 0x1000, expected 0x5a505530 |
| Result slot n | 0x1010 + 4*n (maximum 60 slots) |
| Scratch reservation | 0x1200..0x15ff |
| Stack reservation | 0x7000..0x7fff |
| Initial/program baseline SP | 0x7ff8 |
| Stack-test frame | 0x7800; relocation test also uses 0x7400 |

Reset must supply a valid aligned RAM SP for the initial immediate push. Common
setup then selects SP using POPSP. Interrupts must remain disabled. Completion is
cleared at entry and set only after the result stores finish. Halt at BREAKPOINT,
after preceding stores complete.

There are no emulation vectors: Tier 0 must never execute an extended instruction.
Do not combine these images with application crt0 or bootloader code. Tier 1
needs a separate vector-aware linker layout. If changing the platform, update
`common/test.ld`, `common/tier0.inc` and `manifest.json` together; the Java adapter
also currently enforces this fixed layout.

## Verify that failures are detected

Host checks of the reader, not CPU execution:

```sh
python3 -m unittest discover -s checks -v
```

Negative reference executions, not normal CPU-test passes:

```sh
python3 tools/check_negative_runs.py --jar /path/to/zpusim.jar
```

The latter executes a program with its first ADD changed to AND, an early
breakpoint, and a one-instruction budget. Each must be rejected for the correct
reason. These are deliberately corrupted programs, not mutant CPU cores. Normal
sources/build files are not changed. Evidence goes in fresh `runs/negative-*/`.

Exit codes for run.py: 0 = successful build/all checks pass; 1 = result mismatch
or failed reference run; 2 = command/file/format/build error. Consult the recorded
outcomes to distinguish execution faults from wrong values.

## Extending tests

The original four files are hand-written. Additional table-driven assembly files
and manifest entries are generated by `tools/expand_cases.py`. Edit that generator
and run it deliberately when changing those cases; it overwrites its named files.
Always rebuild before execution. Expected arithmetic uses Python integers masked
to 32 bits. The executed implementation is the independent upstream Java CPU.

`VALIDATION.md` records what has actually been run and what remains outstanding.

Editing `tools/ReferenceRunner.java` requires rebuilding the included bytecode
and its checksum records. That BUILD step needs a Java 11+ JDK; ordinary users
running the suite need only Java 8:

```sh
python3 tools/build_adapter.py --jar /path/to/zpusim.jar
```

For a build JDK lacking `--release 8` API symbols, add
`--java8-rt-jar /path/to/a/verified/java8/lib/rt.jar`.
