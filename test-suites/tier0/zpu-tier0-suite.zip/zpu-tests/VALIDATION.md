# Validation record

The final suite was built and executed in this cloud workspace. These results
do not establish readiness of the team's Questa backend, C++ simulator or RTL.

| Check | Outcome |
| --- | --- |
| Assemble/link | All 19 programs passed |
| Opcode and code/result separation scans | Passed; required opcodes only |
| Binary versus big-endian hex packing | All 19 images matched |
| Original Zylin Java simulator | Java 8 (Temurin 1.8.0_472): all 19 programs passed; 500 result checks passed |
| Trace validation | One row per opcode in straight-line tests; image/PC/count checks passed |
| Host reader/trace safeguards | 16 tests passed; not CPU tests |
| First ADD changed to AND in a separate program | Rejected: slot 0 mismatch |
| Early breakpoint in a separate program | Rejected: incomplete execution |
| One-instruction budget | Rejected: TIMEOUT |
| Team Questa / C++ simulator / RTL | NOT RUN here |

Positive evidence: `evidence/java-reference/summary.json`, with real per-test
RAM dumps, pre-execution traces, statuses and image/manifest/adapter hashes.
All were checked against the current files before packaging. The adapter
excludes upstream profiler reads from instruction counts and traces. A host
regression check rejects duplicate profiler rows.

Negative evidence: `evidence/negative-executions/summary.json`. These are
deliberately corrupted PROGRAMS or incomplete runs, not mutant CPU cores.
No target pass is inferred from synthetic host-test fixtures.

The unmodified upstream simulator JAR is pinned in `reference.json` and is
not redistributed. See README.md for commands and platform assumptions.
Reference disagreements still require investigation against the agreed ISA.

## Program results

| Program | Result checks | Outcome |
| --- | ---: | --- |
| immediates | 9 | PASS |
| addition | 6 | PASS |
| bitwise | 12 | PASS |
| memory | 5 | PASS |
| im_patterns | 16 | PASS |
| add_carries | 32 | PASS |
| flip_bits | 32 | PASS |
| stack_pointer | 10 | PASS |
| loadsp_low | 48 | PASS |
| loadsp_high | 48 | PASS |
| storesp_low | 48 | PASS |
| storesp_high | 48 | PASS |
| addsp_offsets | 48 | PASS |
| poppc | 6 | PASS |
| memory_patterns | 32 | PASS |
| nop | 4 | PASS |
| and_bits | 32 | PASS |
| or_bits | 32 | PASS |
| not_bits | 32 | PASS |

## Java 8 compatibility update

The adapter now ships as checksum-verified Java 8 bytecode in `tools/java8/`.
Normal execution requires only Java 8+ JRE, not a JDK or Java 11 source launcher.
All 500 result checks and the three negative executions were rerun on a real
Temurin Java 8 JRE. A POPPC compatibility smoke test also passed on Java 21.
The Java 8 validation runtime was downloaded from Adoptium's official GitHub
release jdk8u472-b08 and verified against its published SHA-256 before use.

Four new host checks cover compiled-class launching, modified source/bytecode
rejection, and rejection of class formats newer than Java 8. Runtime and source
versions are recorded in `evidence/java-reference/summary.json`.
