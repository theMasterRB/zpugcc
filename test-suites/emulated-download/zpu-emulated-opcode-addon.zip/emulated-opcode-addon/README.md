# Emulated opcode test add-on

This download adds only the new software-handler tests to your existing Tier 0
suite. It contains no original tier0/*.S programs, replacement shared checker,
CRT handler implementation, C++ core or separate Java simulator.

1. Switch your repository to its emulated-opcode branch (or a new branch based on it).
2. Extract this add-on outside your repository.
3. From this extracted folder, run the following, replacing the path with your
   existing test folder:

```sh
python3 install.py /path/to/your/repo/software/zpu-tests
```

The installer checks shared dependencies and file collisions before writing.
It adds new files, retains existing files, and appends the Git ignore/attribute
rules needed to commit the new prebuilt images and Java classes. A differing
existing add-on file stops installation; your edits are not overwritten.

Requires the original combined Tier 0 kit with its Java 8-compatible adapter,
shared tools/run.py, common/tier0.inc, manifest.json and bundled Zylin simulator.
Keep your existing software/crt0Stuff/crt0.S. If its contents differ from the
version used for these images, the runner requires a rebuild using zpu-elf-gcc
and binutils before execution.

Then from your software/zpu-tests folder:

```sh
sh run_tests.sh
sh run_emulated_tests.sh reference
```

With g++ and the team's simulator/zpu_core.cpp and zpu_core.h available:

```sh
sh run_emulated_tests.sh cpp
```

The new group has 26 programs / 1,019 result checks for 22 implemented handler
families. Eight empty slots remain explicitly unimplemented. See EMULATED.md
inside the installed test folder. Java 8+ and Python 3.7+ are required.

Review the new files and three Git configuration additions in GitHub Desktop,
commit on your test branch, then open a PR into your emulated-opcode branch.
The private repository itself was not accessed or changed by creating this kit.
