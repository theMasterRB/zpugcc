# ZPU software test kit

From this extracted folder:

```sh
cd software/zpu-tests
python3 tools/verify_bundle.py
sh run_tests.sh
sh run_emulated_tests.sh reference
```

Requires Python 3.7+ and Java 8+. With g++ installed, also run:

```sh
sh run_emulated_tests.sh cpp-tier0
sh run_emulated_tests.sh cpp
```

The original Tier 0 tests have 19 programs / 500 checks. The software-handler
group adds 26 programs / 1,019 checks across 22 implemented opcode families.
Eight empty handler slots are explicitly not implemented. See
`software/zpu-tests/EMULATED.md`, `VALIDATION.md` and `PR_DESCRIPTION.md`.

The original CRT handler and C++ core sources from the opcodes branch are
included unchanged. Keep the software/ and simulator/ layout intact. There
is no nested Git repository. Bundled upstream Java simulator source and notices
are under software/zpu-tests/reference/ and must accompany it.
